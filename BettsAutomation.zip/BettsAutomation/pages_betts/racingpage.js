import { test, expect } from '@playwright/test';

export class RacingPage{

    constructor(page) {

        this.page = page

        this.lnk_Horse = page.locator("//div[contains(text(),'Horse')]")
        this.lnk_Grehound = page.locator("//div[contains(text(),'Greyhound')]")
        this.lnk_Harness = page.locator("//div[contains(text(),'Harness')]")
        this.lnk_KironVirtual = page.locator("//div[contains(text(),'Kiron')]")
        this.lnk_Today = page.locator("//div[contains(text(),'Today')]")
        this.lnk_Tomorrow = page.locator("//div[contains(text(),'Tomorrow')]")
        this.lnk_All = page.locator("//div[contains(text(),'All')]")
        this.lnk_AustrailiaAndNZ = page.locator("//div[contains(text(),'Australia')]")
        this.lnk_Virtual = page.locator("//div[contains(text(),'All')]/following::div[contains(text(),'Virtual')]")
        this.lnk_UKAndIreland = page.locator("//div[contains(text(),'UK')]")
        this.lnk_France = page.locator("//div[contains(text(),'France')]")
        this.lnk_USA = page.locator("//div[contains(text(),'USA')]")
        this.lnk_Other = page.locator("//div[contains(text(),'Other')]")

        /** =============================SIS Races (SIS Races are races except australia)============================= */
        this.lnk_FirstAvailableSISRace = page.locator("//h3[text()='Virtual']/following::span[text()='NEXT'][1]/following::span[2]")

        /** =============================Tab Races (TAB Races are races in Auztralia and NZ)============================= */
       // this.lnk_lastAvailableTABRace = page.locator("//h3[text()='Virtual']/preceding::span[text()='NEXT'][1]/following::span[2]")
        this.lnk_lastAvailableTABRace = page.locator("//div[contains(text(),'Virtual')]/following::span[text()='NEXT'][1]/following::span[2]")
        this.lnk_FirstAvailableTABRace = page.locator("//div[contains(text(),'Virtual')]/following::span[text()='NEXT'][2]/following::span[2]")

        /* ========Race Card================================*/
        this.btn_FirstSPOddOrBET = page.locator("//div[contains(text(),'Win')]/following::span[@class='mat-button-wrapper'][1]")
        this.btn_SecondSPOddOrBET = page.locator("//div[contains(text(),'Win')]/following::span[@class='mat-button-wrapper'][2]")
        
        /* ========Today tab================================*/

        /* ========Tomorow tab================================*/
        this.lnk_FirstRaceInTomorrowTabForSIS = page.locator("//h3[contains(text(),'UK')]/following::span[text()='NEXT'][1]/following::span[1]")
        this.lnk_FirstRaceInTomorrowTabForTAB = page.locator("//h3[contains(text(),'UK')]/following::span[text()='NEXT'][1]/following::span[1]")
        
        /* ========Horse tab================================*/
        
        
        /* ========Greyhound tab================================*/

        /* ========Harness tab================================*/

        /* ========Kiran Virtual tab================================*/
        this.btn_FirstBet = page.locator("//div[contains(text(),'Kiron')]/following::span[contains(text(),'BET')][1]")
        this.btn_SecondtBet = page.locator("//div[contains(text(),'Kiron')]/following::span[contains(text(),'BET')][2]")
        this.btn_FirstUpcomingRace = page.locator("//mat-panel-title[contains(text(),'UPCOMING')]/following::div[@data-swiper-slide-index='1']/button")
        /* ========Nuwara Eliya tab================================*/

        /* ========All tab================================*/

        /* ========Autralia & NZ tab================================*/     
        
         /* ========Virtual================================*/
         this.lnk_FirstRaceInVirtualTab = page.locator("//div[contains(text(),'Virtual')]/following::span[text()='NEXT'][1]/following::span[1]")

         /* ========Other================================*/

         /* ========Detail Race View(Race Card)================================*/

    }

    //Click on Horse, Greyhound, Harness & Kiron Virtual
     async rc_ClikOnRacingType(raceType) {
        await this.page.waitForTimeout(5000)
        //click on a tab
        switch (raceType) {
            case "Horse":
                await this.lnk_Horse.click()
                break;
            case "Greyhound":
                await this.lnk_Grehound.click()
                break;
            case "Harness":
                await this.lnk_Harness.click()
                break;
            case "Kiron":
                await this.lnk_KironVirtual.click()
                break;            
            default:
                console.log("Entered item name is incorrect & Please enter a correct item name to click")
        }
        await this.page.waitForTimeout(5000)
    }
    
    //Navigates to today & tomorrow sections 
    async rc_NavigatesToTodayOrTomorowTab(todayOrTommorow) {
        if(todayOrTommorow==="Today"){
            //await this.page.waitForTimeout(1000)
            //click on Add to bet slip button       
            await this.lnk_Today.click()
        }
        else{
            await this.lnk_Tomorrow.click()
        }

    }
      
    //Click on All or Australia & NZ....
    async rc_NavigatesToAllAusNZVirtual(raceType) {
        await this.page.waitForTimeout(5000)
        //click on a tab
        switch (raceType) {
            case "All":
                await this.lnk_All.click()
                break;
            case "NZ":
                await this.lnk_AustrailiaAndNZ.click()
                break;
            case "Virtual":
                await this.lnk_Virtual.click()
                break;
            case "UK":
                await this.lnk_UKAndIreland.click()
                break;
            case "France":
                await this.lnk_France.click()
                break;
            case "USA":
                await this.lnk_USA.click()
                break;
            case "Other":
                await this.lnk_Other.click()
                break;
            default:
                console.log("Entered item name is incorrect & Please enter a correct item name to click")
        }
       // await this.page.waitForTimeout(5000)

    }
    
    //Click on the first available next race
    async rc_ClickOnAvailableFirstNextRace(raceType) {
        
        await this.page.waitForTimeout(5000)
        if(raceType==="SIS"){
            //Click on the first available next race
            await this.lnk_FirstAvailableSISRace.click()
        }
        else if(raceType==="TAB"){
            //Click on the first available TAB race
            await this.lnk_lastAvailableTABRace.click()
        }
        else if(raceType==="Virt"){
            //Click on the first available Virtual race
            await this.lnk_FirstRaceInVirtualTab.click()         

        }  
        else if(raceType==="1stTAB"){

            await this.lnk_FirstAvailableTABRace.click()
        }    

    }

    //Click on the second available next race
    async rc_ClickOnAvailableSecondNextRace(raceType) {
        
        await this.page.waitForTimeout(5000)
       
            //Click on the second available next race
            await this.lnk_FirstAvailableSISRace.click()
        
    }

    //Click on SP button or ODD button from Race card
    async rc_ClickSPOddOrBetButton(selection) {

        await this.page.waitForTimeout(5000)
        if(selection==="1st"){
            //Click on SP or BET button
            await this.btn_FirstSPOddOrBET.click()
        }
        else if(selection==="2nd"){
            //Click on SP or BET button
            await this.btn_SecondSPOddOrBET.click()
        }        
    }

     //Click on BET button for kiron virtual races
     async rc_ClickBetButton(selection) {

        await this.page.waitForTimeout(5000)
        if(selection==="1st"){
            //Click on SP or BET button
            await this.btn_FirstBet.click()
        }
        else if(selection==="2nd"){
            //Click on SP or BET button
            await this.btn_SecondtBet.click()
        }        
    }

    //Click on the first available next race
    async rc_ClickOnAvailableFirstNextRaceFromTomorrowTab(SISorTab) {
        
        await this.page.waitForTimeout(2000)
        if(SISorTab==="SIS"){
            //Click on the first available next race
            await this.lnk_FirstRaceInTomorrowTabForSIS.click()
        }
        else if(SISorTab==="TAB"){
            //Click on the first available TAB race
            
        }      

    }

     //Click on the first upcomming race
     async rc_ClickOnUpcomingRaces(raceNumber) {
        
        await this.page.waitForTimeout(2000)
        if(raceNumber==="1st"){
            //Click on the first available next race
            await this.btn_FirstUpcomingRace.click()
        }
        else if(raceNumber==="2nd"){
            //Click on the first available TAB race            
        }
    }

}

