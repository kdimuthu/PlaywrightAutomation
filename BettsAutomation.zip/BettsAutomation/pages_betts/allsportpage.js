import { test, expect } from '@playwright/test';

export class AllSportPage{

    constructor(page) {

        this.page = page

        /* ======== All Sport  ==========================================*/ 

        this.icn_CricketFromAllSports = page.locator("//span[text()='All Sports']/following::img[1]")
        this.icn_RugbyFromAllSports = page.locator("//span[text()='All Sports']/following::img[2]")     
        this.icn_SoccerFromAllSports = page.locator("//span[text()='All Sports']/following::img[3]")
        this.lnk_BasketBall = page.locator("//span[text()='All Sports']/following::span[text()='Basketball']") 
        this.lnk_Boxing = page.locator("//span[text()='All Sports']/following::span[text()='Boxing']") 
        this.lnk_Cricket = page.locator("//span[text()='All Sports']/following::span[text()='Cricket'][2]")  
        this.lnk_Formula1 = page.locator("//span[text()='All Sports']/following::span[text()='Formula 1']")        
        this.lnk_Rugby = page.locator("//span[text()='All Sports']/following::span[text()='Rugby'][1]")
        this.lnk_Soccer = page.locator("//span[text()='All Sports']/following::span[text()='Soccer'][1]")
        this.lnk_Tennis = page.locator("//span[text()='All Sports']/following::span[text()='Tennis'][1]")

    }  

    //Click on a cricket, rugby or soccer game
    async rc_NavigatesToCricketRugbyOrSoccerFromAllSportsSection(sportName) {
        //Click on Cricket
        if(sportName==="Cricket"){
            await this.icn_CricketFromAllSports.click()
        }
        //Click on Rugby
        else if(sportName==="Rugby"){
            await this.icn_RugbyFromAllSports.click()
        }
        //Click on soccer
        else if(sportName==="Soccer"){
            await this.icn_SoccerFromAllSports.click()
        }

    }    

    //Click on a sport
    async rc_ClickOnASport(sportName) {
        await this.page.waitForTimeout(5000)
        //click on a sport
        switch (sportName) {
            case "Basketball":
                await this.lnk_BasketBall.click()
                break;
            case "Boxing":
                await this.lnk_Boxing.click()
                break;
            case "Cricket":
                await this.lnk_Cricket.click()
                break;
            case "Formula1":
                await this.lnk_Formula1.click()
                break;
            case "Rugby":
                await this.lnk_Rugby.click()
                break;
            case "Soccer":
                await this.lnk_Soccer.click()
                break;
            case "Tennis":
                await this.lnk_Tennis.click()
                break;
            default:
                console.log("Entered item name is incorrect & Please enter a correct item name to click")
        }
    }
     
    
}