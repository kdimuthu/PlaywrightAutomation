import { test, expect } from '@playwright/test';

export class SoccerPage{

    constructor(page) {

        this.page = page

        /* ======== Heading ==========================================*/

        this.lnk_Matches = page.locator("//div[contains(text(),'Matches')]")
        this.lnk_Tournaments = page.locator("//div[contains(text(),'Tournaments')]")
        this.lnk_Outrights = page.locator("//div[contains(text(),'Outrights')]")       

        /*========= Matches ==========================================*/

        this.lnk_Today = page.locator("//div[contains(text(),'Today')]")
        this.lnk_Tomorrow = page.locator("//div[contains(text(),'Tomorrow')]")
        this.lnk_Future = page.locator("//div[contains(text(),'Future')]")        

        /*========= Tournaments ======================================*/

        this.btn_FirstOddButtOnFirstRaceInTomorrow = page.locator("//div[contains(text(),'Matches')]/following::p[2]")

        /*========= Outrights ========================================*/

        this.lnk_FirstOutrights = page.locator("//div[contains(text(),'Outrights')]/following::mat-panel-title[1]")
        this.lnk_SecondOutrights = page.locator("//div[contains(text(),'Outrights')]/following::mat-panel-title[2]")
        this.btn_FirstOddInFirstOutright = page.locator("//div[contains(text(),'Outrights')]/following::span[@class='mat-button-wrapper'][1]")
        this.btn_SecondOddInFirstOutright = page.locator("//div[contains(text(),'Outrights')]/following::span[@class='mat-button-wrapper'][2]")
        this.btn_FirstOddInSecondOutright = page.locator("//div[contains(text(),'Outrights')]/following::span[@class='mat-button-wrapper'][3]")
        this.btn_SecondOddInSecondOutright = page.locator("//div[contains(text(),'Outrights')]/following::span[@class='mat-button-wrapper'][4]")

        /*========= Today ============================================*/

        this.lnk_FirstGame = page.locator("//div[contains(text(),'Today')]/following::div[@class='sport-item'][1]/div")
        this.btn_FirstOddOnFirstGame = page.locator("//div[contains(text(),'Today')]/following::span[@class='mat-button-wrapper'][1]")
        this.btn_FirstOddOnSecondGame = page.locator("//div[contains(text(),'Today')]/following::span[@class='mat-button-wrapper'][4]")

        /*========= Tomorrow =========================================*/

        /*========= Future ===========================================*/

        /*========= Single Sport View =================================*/

        this.btn_FirstOddButtonInWinnerMarket = page.locator("//mat-panel-title[contains(text(),'Winner')]/following::span[@class='mat-button-wrapper'][1]")
        this.btn_SecondOddButtonInWinnerMarket = page.locator("//mat-panel-title[contains(text(),'Winner')]/following::span[@class='mat-button-wrapper'][2]")
        this.lnk_SecondMarket = page.locator("//mat-panel-title[contains(text(),'Match Winner')]/following::mat-panel-title[1]")
        this.btn_FirstOddInSecondMarket = page.locator("//mat-panel-title[contains(text(),'Match Winner')]/following::mat-panel-title[1]/following::span[2]")
        this.btn_SecondOddInSecondMarket = page.locator("//mat-panel-title[contains(text(),'Match Winner')]/following::mat-panel-title[1]/following::span[6]")
    }  
    
    //Click on Matches, Tournaments or Outrights
    async rc_ClickOnMatchesTournamentsOrOutrights(type) {

        await this.page.waitForTimeout(5000)
        if(type==="Match"){
            //Click on matches link
            await this.lnk_Matches.click()
        }
        else if(type==="Tournament"){
            //Click on lnk_Tournaments
            await this.lnk_Tournaments.click()
        }
        else if(type==="Outrights"){
            //Click 
            await this.lnk_Outrights.click()
        }
    }

    //Click on Today, Tomorrow or Future
     async rc_ClickTodayTommorowOrFuture(type) {
        await this.page.waitForTimeout(5000)
        if(type==="Today"){
            //Click on today link
            await this.lnk_Today.click()
        }
        else if(type==="Tomorrow"){
            //Click on Tomorrow
            await this.lnk_Tomorrow.click()
        }
        else if(type==="Future"){
            //Click on Future
            await this.lnk_Future.click()
        }
    }

    //Click on the first game
    async rc_ClickOnFirstGame() {        
      
        //Click on first game
        await this.lnk_FirstGame.click()
        
    }

    //Click on the odd buttons in winner market
    async rc_ClickOnOddButtonInWinnerMarket(FirstOrSecond) {       

        await this.page.waitForTimeout(5000)
        if(FirstOrSecond==="First"){
            //Click on first odd button in winner market
            await this.btn_FirstOddButtonInWinnerMarket.click()
        }
        else if(FirstOrSecond==="Second"){
            //Click on second button in winner market
            await this.btn_SecondOddButtonInWinnerMarket.click()
        }   

    }

    //Click on the second market line
    async rc_ClickOnSecondMarket() {        
      
        //Click on first market line
        await this.lnk_SecondMarket.click()
        
    }   
    
    //Click on the odd buttons in second market
    async rc_ClickOnOddButtonInSecondMarket(FirstOrSecond) {       

        await this.page.waitForTimeout(5000)
        if(FirstOrSecond==="First"){
            //Click on first odd button in winner market
            await this.btn_FirstOddInSecondMarket.click()
        }
        else if(FirstOrSecond==="Second"){
            //Click on second button in winner market
            await this.btn_SecondOddInSecondMarket.click()
        }   

    }

     //Click on the odd buttons from sports view
    async rc_ClickOnOddButtonsFromSportView(FirstOrSecond) {       

        await this.page.waitForTimeout(5000)
        if(FirstOrSecond==="First"){
            //Click on first odd button in winner market
            await this.btn_FirstOddOnFirstGame.click()
        }
        else if(FirstOrSecond==="Second"){
            //Click on second button in winner market
            await this.btn_FirstOddOnSecondGame.click()
        }   

    }

    //Expand the first game in outrights tab
    async rc_ExpandAGameInOutrightGame(gameNumber) {      
        
        await this.page.waitForTimeout(5000)
        if(gameNumber==="First"){
            //Click on first outrights game
            await this.lnk_FirstOutrights.click()
        }
        else if(gameNumber==="Second"){
            //Click on second button in winner market
            await this.lnk_SecondOutrights.click()
        }        
    } 
    
     //Click on the odd buttons in first outright
     async rc_ClickOnOddButtonInFirstOutright(FirstOrSecond) {
       
        if(FirstOrSecond==="First"){
            //Click on first odd button in winner market
            await this.btn_FirstOddInFirstOutright.click()
        }
        else if(FirstOrSecond==="Second"){
            //Click on second button in winner market
            await this.btn_SecondOddInFirstOutright.click()
        }   

    }
    
}