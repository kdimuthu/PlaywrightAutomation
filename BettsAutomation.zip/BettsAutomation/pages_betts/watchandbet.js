import { test, expect } from '@playwright/test';

export class WatchAndBetPage{

    constructor(page) {

        this.page = page

        /* ======== Heading  ==========================================*/
        this.msg_YouDontHaveAccess = page.locator("//p[contains(text(),'feature')]")     

    }  

    //Verify the validation message when punter doesn't have accecs to Watch and bet
    async rc_VerifyFailMessageWhenNoAccessToWatchAndBet() {

        await this.page.waitForTimeout(3000)
        //Verify fail message
        expect(this.msg_YouDontHaveAccess, 'Fail message is showing correctly').toHaveText("You don't have access for this feature. Please contact Administrator")
    }    
    
}