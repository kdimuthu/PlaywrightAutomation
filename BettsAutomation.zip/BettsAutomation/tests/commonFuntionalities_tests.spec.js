
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { login } from '../testdata/testdata.json'
import { DepositPage } from '../pages_betts/depositpage.js';
import { CricketPage } from '../pages_betts/cricket.js';
import { Next15Page } from '../pages_betts/next15page.js';


//Verify that punter is able deposit money
test('tc_CF001_VerifyThatUserIsableToDoADeposit',async ({page})=>{
    const _HomePage=new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()  
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username,login[0].password,"No") 
    //Store credit balance before a deposit
    const beforeBalance=await _HomePage.rc_StoreCreditBalance()  
    //Click login profile icon to navigates to My bets secion
    await _HomePage.rc_ClickProfileIconAfterLogin()
    //Click on My Betss
    await _HomePage.rc_ClickAnItemFromRighMenu("Deposit")
    const _DepositPage=new DepositPage(page)
    //Enter amount
    await _DepositPage.rc_EnterAnAmountAndClickVisaMasterOrIpay("Visa")
    //Enter card detail
    await _DepositPage.rc_EnterCardDetailsAndClickPayNow()   
    //Click ok from success pop up
    await _DepositPage.rc_ClickOkFromSuccessPopup()    
    //Store credit balance before a deposit
    const afterBalance=await _HomePage.rc_StoreCreditBalance() 
    //Verify credit balance is increased after a deposit
    await _HomePage.rc_VerifyCreditBalanceIsIncreasedAfterADeposit(beforeBalance,afterBalance) 
   // await page.pause()  

}) 

//Verify the odd format changing funtionality
test('tc_CF002_VerifyThatOddFormatChangingFuntionality',async ({page})=>{
    const _HomePage=new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication() 
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
    //Click login profile icon to navigates to My bets secion
    //Click on Next15
    await _HomePage.rc_ClickAnItemFromTopMenu("Next")    
    const _Next15Page = new Next15Page(page)
    //Store the fraction decimal status by default
    const fractionDecimalStatus=await _Next15Page.rc_StoreDecimalOrFractionStatus()
    //Click profile icon
    await _HomePage.rc_ClickProfileIconAfterLogin() 
    //Verify odd format changing funtionality
    await _HomePage.rc_VerifyOffChangingFuntionality(fractionDecimalStatus)  
   // await page.pause()
}) 

//Verify the bets in recent bets
test('tc_CF003_VerifyTheBetsInRecentBets',async ({page})=>{
    const _HomePage=new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication() 
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username,login[0].password,"No") 
    //Click on Cricket tab
    await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
    const _CricketPage=new CricketPage(page)
    //Click on first game   
    await _CricketPage.rc_ClickOnFirstGame()
    //Click on first ODD
    await _CricketPage.rc_ClickOnOddButtonInWinnerMarket("First")  
    //Enter bet amount
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
    //Click Place Bet button
    _HomePage.rc_ClickPlaceBet()  
    //Store slip id and click Ok from succuss messge  
    const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
    //Click recent betss
    _HomePage.rc_ClickRecentBets()
    //Verify slip id
    _HomePage.rc_VerifyBettsInRecentBetss(slipId)    
}) 

//Verify the result page load the result
test('tc_CF004_VerifyResultPageLoadResults',async ({page})=>{
    const _HomePage=new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication() 
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username,login[0].password,"No")  
    //Click results
    await _HomePage.rc_ClickResults()
    //Verify results
    await _HomePage.rc_VerifyResultsLoaded()   
}) 

//Verify that racing post is opened in a new browser when clicking on racing post from news feed
test('tc_CF005_VerifyThatRacingPostIsOpenedInANewBrowserWhenClickingOnRacingPostFromNewsFeed',async ({page})=>{
    const _HomePage=new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication() 
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
    //Click Racing post
    await _HomePage.rc_ClickRacingPostOrSportingLifeFromNewsFeed("Racing")    
    //await page.pause()     
}) 

//Verify that sporting life is opened in a new browser when clicking on racing post from news feed
test('tc_CF006_VerifyThatSportingLifeIsOpenedInANewBrowserWhenClickingOnSportingLifeNewsFeed',async ({page})=>{
    const _HomePage=new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication() 
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username,login[0].password,"No")   
    //Click Racing post
    await _HomePage.rc_ClickRacingPostOrSportingLifeFromNewsFeed("Sporting")      
    //await page.pause()   
}) 


