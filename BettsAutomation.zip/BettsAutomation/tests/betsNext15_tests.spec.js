
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { login } from '../testdata/testdata.json'
import { Next15Page } from '../pages_betts/next15page.js';


//Verify Minimum Slip Amount Validation
test('tc_NF001_VerifyMiniumuSlipAmountValidation', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
    //Click on Next15
    await _HomePage.rc_ClickAnItemFromTopMenu("Next")
    //Click on a Bet
    const _Next15Page = new Next15Page(page)
    await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(1)
    //Enter bet amount
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'25')
    //Click Place Bet button
    await _HomePage.rc_ClickPlaceBet()
    //Verify validation
    await _HomePage.rc_VerifyMinimumSlipAmountValidation()
})

//Verify Minimum Stake Value Validation
test('tc_NF002_VerifyMiniumuStakeValueValidation', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
    //Click on Next15
    await _HomePage.rc_ClickAnItemFromTopMenu("Next")
    //Click on a Bet for first race
    const _Next15Page = new Next15Page(page)
    await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(1)
    //Click on a Bet for second race
    await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(2)
    //Enter bet amount for first race slip
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'20')
    //Enter bet amount for first race slip
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place",'5')
    //Click Place Bet button
    await _HomePage.rc_ClickPlaceBet()
    //Verify validation
    await _HomePage.rc_VerifyMinimumStakeValueValidation()
     
})

//Verify that user is able to place a bet via Next15
test('tc_NF003_VerifyThatUserIsAbleToPlaceABetViaNext15', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
    //Click on Next15
    await _HomePage.rc_ClickAnItemFromTopMenu("Next")
    //Click on a Bet for first race
    const _Next15Page = new Next15Page(page)
    await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(1)
    //Enter bet amount for first race slip
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'100')
    //Click Place Bet button
    await _HomePage.rc_ClickPlaceBet()
    //Verify Bet succuss message
    await _HomePage.rc_VerifyBettsSuccessMessage()
    //await page.pause()
})

//Verify that user is not able to bet more than to the available credit balance
test('tc_NF004_VerifyThatUserIsUnableToPlaceABetMoreThanToCreditBalance', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username, login[0].password,"No") 
    //Store credit balance
    const val=await _HomePage.rc_StoreCreditBalance()        
    //Click on Next15
    await _HomePage.rc_ClickAnItemFromTopMenu("Next")
    //Click on a Bet for first race
    const _Next15Page = new Next15Page(page)
    await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(1)
    //Enter bet amount for first race slip    
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",val+5) 
    //Click Place Bet button
    await _HomePage.rc_ClickPlaceBet()
    //Verify the validation  message
    await _HomePage.rc_VerifyValidationMessageWhenThereIsNoSufficientBalance()
    //await page.pause()
})

//Verify that user is able to place a bet via Next15
test('tc_NF005_VerifyThatUserIsAbleToPlaceABetForARaceTodaysMeeting', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
    //Click on Next15
    await _HomePage.rc_ClickAnItemFromTopMenu("Next")    
    //Click on a Bet for first race      
    const _Next15Page = new Next15Page(page)
    _Next15Page.rc_ClickOnBetSPOrOddButton("BET")    
    //Enter bet amount for first race slip
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
    //Click Place Bet button
    await _HomePage.rc_ClickPlaceBet()
    //Verify Bet succuss message
    await _HomePage.rc_VerifyBettsSuccessMessage()
    //await page.pause()
})

//Verify that races are dispalyed based on categories in Next 15 page
test('tc_NF006_VerifyRacesAreDisplayedAsPerCategoriesInNext15Page', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click Horce tab
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_ClickOnARacingType("Horse")
  //Verify Horce Races
  await _Next15Page.rc_VerifyHorseRacesAreShowingInHorceTab()
  //Click Greyhound tab
  await _Next15Page.rc_ClickOnARacingType("Greyhound")
  //Verify greyhound races
  await _Next15Page.rc_VerifyGreyhoundRacesAreShowingInGreyhoundTab()
  //Click Harness tab
  await _Next15Page.rc_ClickOnARacingType("Harness")
  //Verify harness races
  await _Next15Page.rc_VerifyHarnessRacesAreShowingInHarnessTab()

})

//Verify that user is able to place a win single bet by selecting an BET button
test('tc_NF007_VerifyPlacingAWinSingleBetBySelectingBET', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a odd value
  const _Next15Page = new Next15Page(page)
  _Next15Page.rc_ClickOnBetSPOrOddButton("BET")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")

})

//Verify that user is able to place a win single bet by selecting an oddValue
test('tc_NF008_VerifyPlacingAWinSingleBetBySelectingAnOddValue', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a odd value
  const _Next15Page = new Next15Page(page)
  _Next15Page.rc_ClickOnBetSPOrOddButton("Odd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")

})

//Verify that user is able to place a win single bet by selecting SP button
test('tc_NF009_VerifyPlacingAWinSingleBetBySelectingSPButton', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a odd value
  const _Next15Page = new Next15Page(page)
  _Next15Page.rc_ClickOnBetSPOrOddButton("SP")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")

})

//Verify that user is able to place a win & place single bet by clickin on BET button
test('tc_NF010_VerifyPlacingAWinAndPlaceSingleBetBySelectingBETbutton', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a odd value
  const _Next15Page = new Next15Page(page)
  _Next15Page.rc_ClickOnBetSPOrOddButton("BET")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("WinAndPlace",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Win","30")
  //Verify bet details for second selction
  await _HomePage.rc_VerifyBetDetailsWhenBettinsForMultipleSelection("Place","30")

})

//Verify that user is able to place a win & place single bet by clickin on odd
test('tc_NF011_VerifyPlacingAWinAndPlaceSingleBetBySelectingOddValue', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a odd value
  const _Next15Page = new Next15Page(page)
  _Next15Page.rc_ClickOnBetSPOrOddButton("Odd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("WinAndPlace",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Win","30")
  //Verify bet details for second selction
  await _HomePage.rc_VerifyBetDetailsWhenBettinsForMultipleSelection("Place","30")

})

//Verify that user is able to place a win & place single bet by clickin on SP
test('tc_NF012_VerifyPlacingAWinAndPlaceSingleBetBySelectingSPButton', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a SP button
  const _Next15Page = new Next15Page(page)
  _Next15Page.rc_ClickOnSPOnNonFavouriteSelectionToGetWinAndPlace()
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("WinAndPlace",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Win","30")
  //Verify bet details for second selction
  await _HomePage.rc_VerifyBetDetailsWhenBettinsForMultipleSelection("Place","30")

})

//Verify that user is not able to place a place only bet 
test('tc_NF013_VerifyThatUserIsNotAbleToPutAPlaceOnlyBet', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a BET button of first avaiable race
  const _Next15Page = new Next15Page(page)
  _Next15Page.rc_ClickOnBetSPOrOddButton("BET")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet validation message
  await _HomePage.rc_VerifyValidationWhenPlaceOnlyBetIsPlaced() 

})

//Verify that validation message when place stake is grater than win stake 
test('tc_NF014_UnableToPlaceASingleBetWhenPlaceIsGreaterThanWin', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a BET button of first avaiable race
  const _Next15Page = new Next15Page(page)
  _Next15Page.rc_ClickOnBetSPOrOddButton("BET")
  //Enter an ammount for win bet
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Enter an ammount for place bet
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place",'40')   
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyValidationWhenPlaceIsGraterThanWin()

})

//Verify that user is able to place bet using Each Way by clicking on BET button 
test('tc_NF015_VerifyPlacingABetUsingEachWayByClickingOnBetButton', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a BET button of first avaiable race
  const _Next15Page = new Next15Page(page)
  _Next15Page.rc_ClickOnBetSPOrOddButton("BET")
  //Enter an ammount for win bet
  await _HomePage.rc_EnterAStakeViaEachWay("30")    
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Each Way","60")
})

//Verify that user is able to place bet using Each Way by clicing on ODD button 
test('tc_NF016_VerifyPlacingABetUsingEachWayByClickingOnOddButton', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a BET button of first avaiable race
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_ClickOnBetSPOrOddButton("Odd")
  //Enter an ammount for win bet
  await _HomePage.rc_EnterAStakeViaEachWay("30")    
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
 //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Each Way","60")
})

//Verify that user is able to place bet using Each Way by clicing on SP button 
test('tc_NF017_VerifyPlacingABetUsingEachWayByClickingOnSPButton', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on a ... icon to navigate to racecard
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_ClickOnSPOnNonFavouriteSelectionToGetWinAndPlace()
  //Enter an ammount for win bet
  await _HomePage.rc_EnterAStakeViaEachWay("30")    
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Each Way","60")
})

//Verify that user is able to place bet using forecast
test('tc_NF018_VerifyPlacingABetUsingForecast', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardForSP()
  //Click on forcast
  await _Next15Page.rc_ClickAMarketFromRAceCard("Forecast")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1,"1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2,"2nd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Forecast","30")
})

//Verify that user is able to place bet using reverse forecast
test('tc_NF019_VerifyPlacingABetUsingReverseForecast', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardForSP()
  //Click on forcast
  await _Next15Page.rc_ClickAMarketFromRAceCard("Forecast")
  //Select Any from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1,"Any")
  //Select Any from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2,"Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Reverse Forcast","30")
})

//Verify that user is able to place bet using combination forecast
test('tc_NF020_VerifyPlacingABetUsingCombinationForecast', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardForSP()
  //Click on forcast
  await _Next15Page.rc_ClickAMarketFromRAceCard("Forecast")
  //Select Any from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1,"Any")
  //Select Any from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2,"Any")
  //Select Any from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelection(3,"Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"180","Combination Forcast","30")
})

//Verify that user is able to place bet using tricast
test('tc_NF021_VerifyPlacingABetUsingTricast', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardForSP()
  //Click on Tricast
  await _Next15Page.rc_ClickAMarketFromRAceCard("Tricast")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1,"1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2,"2nd")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3,"3rd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Tricast","30")
})

//Verify that user is able to place bet using reverse tricast
test('tc_NF022_VerifyPlacingABetUsingReverseTricast', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardForSP()
  //Click on Tricast
  await _Next15Page.rc_ClickAMarketFromRAceCard("Tricast")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1,"Any")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2,"Any")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3,"Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"180","Reverse Tricast","30")
})

//Verify that user is able to place bet using combination tricast
test('tc_NF023_VerifyPlacingABetUsingCombinationTricast', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await  _Next15Page.rc_NavigatesToRaceCardForSP()
  //Click on Tricast
  await _Next15Page.rc_ClickAMarketFromRAceCard("Tricast")
  //Select Any from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1,"Any")
  //Select Any from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2,"Any")
  //Select Any from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3,"Any")
  //Select Any from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(4,"Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"720","Combination Tricast","30")
})
//Need to enter a manual test case

//Verify that user is able to place bet using quinella
test('tc_NF024_VerifyPlacingABetUsingQuinella', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for BET
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardUsingBET()
  //Click on quinella
  await _Next15Page.rc_ClickAMarketFromRAceCard("Quinella")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1,"1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2,"2nd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Quinella","30")
})

//Verify that user is able to place bet using Exacta
test('tc_NF025_VerifyPlacingABetUsingExacta', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardUsingBET()
  //Click on Exacta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Exacta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1,"1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2,"2nd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Exacta","30")
})

//Verify that user is able to place bet using Reverse Exacta
test('tc_NF026_VerifyPlacingABetUsingReverseExacta', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardUsingBET()
  //Click on Exacta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Exacta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1,"Any")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2,"Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Reverse Exacta","30")
})

//Verify that user is able to place bet using Trifecta
test('tc_NF027_VerifyPlacingABetUsingTrifecta', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardUsingBET()
  //Click on Trifecta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Trifecta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1,"1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2,"2nd")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3,"3rd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Trifecta","30")
})

//Verify that user is able to place bet using combination Trifecta
test('tc_NF028_VerifyPlacingABetUsingCombinationTrifecta', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardUsingBET()
  //Click on Trifecta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Trifecta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1,"Any")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2,"Any")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3,"Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"180","Combination Trifecta","30")
})

//Verify that user is able to place bet using First4
test('tc_NF029_VerifyPlacingABetUsingFirst4', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardUsingBET()
  //Click on Trifecta
  await _Next15Page.rc_ClickAMarketFromRAceCard("First 4")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(1,"1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(2,"2nd")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(3,"3rd")
  //Select 3rd from selection 4
  await  _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(4,"4th")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss message  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","First 4","30")
})

//Verify that user is able to place bet using Combination First4
test('tc_NF030_VerifyPlacingABetUsingCombinationFirst4', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Navigates to race card for SP
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_NavigatesToRaceCardUsingBET()
  //Click on Trifecta
  await _Next15Page.rc_ClickAMarketFromRAceCard("First 4")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(1,"Any")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(2,"Any")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(3,"Any")
  //Select 3rd from selection 4
  await  _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(4,"Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss message  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"720","Combination First 4","30")
})

//Verify that user is able to place a bet for a horse race in Next 15
test('tc_NF031_VerifyPlacingABetForAHorseRace', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")  
  //Click on a BET
  const _Next15Page = new Next15Page(page)
  //Click on Horse tab
  await _Next15Page.rc_ClickOnARacingType("Horse")
  //Clik on Bet
  _Next15Page.rc_ClickOnBetSPOrOddButton("SP")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
   //Verify Bet succuss message
   await _HomePage.rc_VerifyBettsSuccessMessage()  
  //Store slip id and click Ok from succuss messge
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")

})

//Verify that user is able to place a bet for a Greyhound race in Next 15
test('tc_NF032_VerifyPlacingABetForAGreyhoundRace', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")  
  //Click on a BET
  const _Next15Page = new Next15Page(page)
  //Click on Horse tab
  await _Next15Page.rc_ClickOnARacingType("Greyhound")
  //Clik on Bet
  await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(1)
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
   //Verify Bet succuss message
   await _HomePage.rc_VerifyBettsSuccessMessage()  
  //Store slip id and click Ok from succuss messge
   const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
   await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
   await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
   await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  // await page.pause()

})

//Verify that user is able to place a bet for a Harness race in Next 15
test('tc_NF033_VerifyPlacingABetForAHarnessRace', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")  
  //Click on a BET
  const _Next15Page = new Next15Page(page)
  //Click on Horse tab
  await _Next15Page.rc_ClickOnARacingType("Harness")
  //Clik on Bet
  await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(1)
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()  
  //Store slip id and click Ok from succuss messge
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()
})

//Verify that user is able to place a single bet for two races using multiple options
test('tc_NF034_VerifyPlacingASingleBetForTwoRacesUsingMultipleOptions', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")  
  //Click on a BET
  const _Next15Page = new Next15Page(page)  
  //Clik on Bet for first race
  await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(1)
  //Clik on Bet for second race
  await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(2)
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Single","Win","30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()  
  //Store slip id and click Ok from succuss messge
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Win","30")
  // await page.pause()

})

//Verify that user is able to place a double bet for two races using multiple options
test('tc_NF035_VerifyPlacingADoubleBetForTwoRacesUsingMultipleOptions', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")  
  //Click on a BET
  const _Next15Page = new Next15Page(page)  
  //Clik on Bet for first race
  await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(1)
  //Clik on Bet for second race
  await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(2)
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Double","Win","30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()  
  //Store slip id and click Ok from succuss messge
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForWinDoubleBet(slipId,"30","Double","00")
  // await page.pause()

})



 