
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { login } from '../testdata/testdata.json'
import { CricketPage } from '../pages_betts/cricket.js';
import { SoccerPage } from '../pages_betts/soccerpage.js'
import { AllSportPage } from '../pages_betts/allsportpage.js';

//Verify that punter is able to place a bet for cricket via All Sport icon in All Sport tab
test('tc_All001_VerifyThatUserIsAbleToPlaceABetForCricketSportFromAllSportTabByClickinCricketIconInAllSportSection', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("All")
  //Click on cricket in all sports
  const _AllSportPage=new AllSportPage(page)
  await _AllSportPage.rc_NavigatesToCricketRugbyOrSoccerFromAllSportsSection("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
  
})

//Verify that punter is able to place a bet for Rugby sport via All Sport icon in All Sport tab
test('tc_All002_VerifyThatUserIsAbleToPlaceABetForRugbySportFromAllSportTabByClickinCricketIconInAllSportSection', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("All")
  //Click on soccer in all sports
  const _AllSportPage=new AllSportPage(page)
  await _AllSportPage.rc_NavigatesToCricketRugbyOrSoccerFromAllSportsSection("Rugby")
  const _SoccerPage=new SoccerPage(page)
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","1x2","30")
  //await page.pause()  
 
})

//Verify that punter is able to place a bet for soccer sport via All Sport icon in All Sport tab
test('tc_All003_VerifyThatUserIsAbleToPlaceABetForSoccerSportFromAllSportTabByClickinCricketIconInAllSportSection', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("All")
  //Click on soccer in all sports
  const _AllSportPage=new AllSportPage(page)
  await _AllSportPage.rc_NavigatesToCricketRugbyOrSoccerFromAllSportsSection("Soccer")
  const _SoccerPage=new SoccerPage(page)
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","1x2","30")
  //await page.pause()  
 
})
/* 
//Verify that punter is able to place a bet for basketball sport via All Sport icon in All Sport tab
test('tc_All004_VerifyThatUserIsAbleToPlaceABetForBasketballSportFromAllSportTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("All")
  //Click on soccer in all sports
  const _AllSportPage=new AllSportPage(page)
  await _AllSportPage.rc_ClickOnASport("Basketball")
  const _SoccerPage=new SoccerPage(page)
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
 
})
 */
//Verify that punter is able to place a bet for boxing sport via All Sport icon in All Sport tab
test('tc_All005_VerifyThatUserIsAbleToPlaceABetForBoxingSportFromAllSportTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("All")
  //Click on soccer in all sports
  const _AllSportPage=new AllSportPage(page)
  await _AllSportPage.rc_ClickOnASport("Boxing")
  const _SoccerPage=new SoccerPage(page)
  //Click on first odd button of first game    
  await _SoccerPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
 
})

//Verify that punter is able to place a bet for cricket sport via All Sport icon in All Sport tab
test('tc_All006_VerifyThatUserIsAbleToPlaceABetForCricketSportFromAllSportTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("All")
  //Click on soccer in all sports
  const _AllSportPage=new AllSportPage(page)
  await _AllSportPage.rc_ClickOnASport("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
 
})

//Verify that punter is able to place a bet for formula1 sport via All Sport icon in All Sport tab
test('tc_All007_VerifyThatUserIsAbleToPlaceABetForFormulaSportFromAllSportTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("All")
  //Click on soccer in all sports
  const _AllSportPage=new AllSportPage(page)
  await _AllSportPage.rc_ClickOnASport("Formula1")
  const _CricketPage=new CricketPage(page)
  //Click on outrights
  await _CricketPage.rc_ClickOnMatchesTournamentsOrOutrights("Outrights")
  //Click on first game   
  await _CricketPage.rc_ExpandAGameInOutrightGame("First")
  //Click on first ODD
  await _CricketPage.rc_ClickOnOddButtonInFirstOutright("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
 
})

//Verify that punter is able to place a bet for rugby sport via All Sport icon in All Sport tab
test('tc_All008_VerifyThatUserIsAbleToPlaceABetForRugbySportFromAllSportTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("All")
  //Click on soccer in all sports
  const _AllSportPage=new AllSportPage(page)
  await _AllSportPage.rc_ClickOnASport("Rugby")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
 
})

//Verify that punter is able to place a bet for soccer sport via All Sport icon in All Sport tab
test('tc_All009_VerifyThatUserIsAbleToPlaceABetForSoccerSportFromAllSportTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("All")
  //Click on soccer in all sports
  const _AllSportPage=new AllSportPage(page)
  await _AllSportPage.rc_ClickOnASport("Soccer")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
 
})

//Verify that punter is able to place a bet for tennis sport via All Sport icon in All Sport tab
test('tc_All010_VerifyThatUserIsAbleToPlaceABetForTennisSportFromAllSportTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Soccer tab
  await _HomePage.rc_ClickAnItemFromTopMenu("All")
  //Click on soccer in all sports
  const _AllSportPage=new AllSportPage(page)
  await _AllSportPage.rc_ClickOnASport("Tennis")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
 
})

