
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { login } from '../testdata/testdata.json'
import { CricketPage } from '../pages_betts/cricket.js';

//Verify Minimum Slip Amount Validation for Cricket Sports
test('tc_CR001_VerifyMiniumuSlipAmountValidationForCricketSports', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
    //Click on Cricket tab
    await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
    const _CricketPage=new CricketPage(page)
    //Click on first game   
    await _CricketPage.rc_ClickOnFirstGame()
    //Click on first ODD
    await _CricketPage.rc_ClickOnOddButtonInWinnerMarket("First")
    //Enter bet amount
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'25')
    //Click Place Bet button
    await _HomePage.rc_ClickPlaceBet()
    //Verify validation
    await _HomePage.rc_VerifyMinimumSlipAmountValidation()     
})

//Verify that punter is able to place a bet for cricket sport from Sport View
test('tc_CR002_VerifyThatUserIsAbleToPlaceABetForCricketSportFromSportView', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet from single Sport View
test('tc_CR003_VerifyThatUserIsAbleToPlaceABetForCricketSportFromSingleSportView', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on first game   
  await _CricketPage.rc_ClickOnFirstGame()
  //Click on first ODD
  await _CricketPage.rc_ClickOnOddButtonInWinnerMarket("First")  
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet for different market from single Sport View
test('tc_CR004_VerifyThatUserIsAbleToPlaceABetForDifferentMarketForCricketSportFromSingleSportView', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on first game   
  await _CricketPage.rc_ClickOnFirstGame()
  //Expand a differnt market
  await _CricketPage.rc_ClickOnSecondMarket()
  //Click on first ODD
  await _CricketPage.rc_ClickOnOddButtonInSecondMarket("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place for cricket sports Single bets using multiple options
test('tc_CR005_VerifyThatUserIsAbleToPlaceSingleBetsUsingMultipleOptionsForCricketSports', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on first game   
  await _CricketPage.rc_ClickOnFirstGame()
  //Click on first ODD
  await _CricketPage.rc_ClickOnOddButtonInWinnerMarket("First") 
  //Click on second ODD
  await _CricketPage.rc_ClickOnOddButtonInWinnerMarket("Second")   
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Single","Win","30")  
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss message  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"60","30")  
  //await page.pause()  
})

//Verify that punter is able to place double bets using multiple options
test('tc_CR006_VerifyThatUserIsAbleToPlaceDoulbleBetsUsingMultipleOptionsForCricketSports', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("Second")     
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Double","Win","30")  
  //Click place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss message  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForWinDoubleBetsForCricketSports(slipId,"30","00")     
  //await page.pause()  
})

//Verify that punter is able to place a bet from Sport View from tomorrow tab
test('tc_CR007_VerifyThatUserIsAbleToPlaceABetForCricketSportFromSportViewInTomorrowTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on tomorow tab
  await _CricketPage.rc_ClickTodayTommorowOrFuture("Tomorrow")
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet for winner market from single Sport View from tomorrow tab
test('tc_CR008_VerifyThatUserIsAbleToPlaceABetForAWinnerMarketForCricketSportFromSingleSportViewInTomorrowTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on tomorow tab
  await _CricketPage.rc_ClickTodayTommorowOrFuture("Tomorrow")
  //Click on first game   
  await _CricketPage.rc_ClickOnFirstGame()
  //Click on first ODD
  await _CricketPage.rc_ClickOnOddButtonInWinnerMarket("First")  
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet from Sport View from future tab
test('tc_CR009_VerifyThatUserIsAbleToPlaceABetForCricketSportFromSportViewInFutureTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on tomorow tab
  await _CricketPage.rc_ClickTodayTommorowOrFuture("Future")
  //Click on first odd button of first game    
  await _CricketPage.rc_ClickOnOddButtonsFromSportView("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet from single Sport View from future tab
test('tc_CR010_VerifyThatUserIsAbleToPlaceABetForCricketSportFromSingleSportViewInFutureTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on tomorow tab
  await _CricketPage.rc_ClickTodayTommorowOrFuture("Future")
  //Click on first game   
  await _CricketPage.rc_ClickOnFirstGame()
  //Click on first ODD
  await _CricketPage.rc_ClickOnOddButtonInWinnerMarket("First")  
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

 //Verify that punter is able to place a bet from tounament tab
test('tc_CR011_VerifyThatUserIsAbleToPlaceABetForCricketSportFromTournamentTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on tomorow tab
  await _CricketPage.rc_ClickOnMatchesTournamentsOrOutrights("Tournament")
  //Expand the first game   
  await _CricketPage.rc_ExpandAGameInTournamentsTab("First")
  //Click on tournament name
  await _CricketPage.rc_ClickOnTournamentNameAndNavigateToDetailView()
  //Click on first match
  await _CricketPage.rc_ClickOnFirstMatchForFirstTournament()
  //Click on first ODD
  await _CricketPage.rc_ClickOnOddButtonInWinnerMarket("First")  
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place a bet for cricket sport from outrights tab. 
//This is an issue in outrights tab now. No sports available
test('tc_CR012_VerifyThatUserIsAbleToPlaceABetForCricketSportFromOutrightsTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on Cricket tab
  await _HomePage.rc_ClickAnItemFromTopMenu("Cricket")
  const _CricketPage=new CricketPage(page)
  //Click on tomorow tab
  await _CricketPage.rc_ClickOnMatchesTournamentsOrOutrights("Outrights")
  //Click on first game   
  await _CricketPage.rc_ExpandAGameInOutrightGame("First")
  //Click on first ODD
  await _CricketPage.rc_ClickOnOddButtonInFirstOutright("First")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

