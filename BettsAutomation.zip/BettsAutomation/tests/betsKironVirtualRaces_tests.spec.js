import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { login } from '../testdata/testdata.json'
import { RacingPage } from '../pages_betts/racingpage.js'
import { Next15Page } from '../pages_betts/next15page.js';

//Verify Minimum Slip Amount Validation for Kiron Virtual Races
test('tc_KV001_VerifyMiniumuSlipAmountValidationForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on first Bet button
  await _RacingPage.rc_ClickBetButton("1st")
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'25')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify validation
  await _HomePage.rc_VerifyMinimumSlipAmountValidation()
})

//Verify Minimum Stake Value Validation for kiron virtual races
test('tc_KV002_VerifyMiniumuStakeValueValidationForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on first Bet button
  await _RacingPage.rc_ClickBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'20')
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place", '5')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify validation
  await _HomePage.rc_VerifyMinimumStakeValueValidation()

})

//Verify that user is able to place a win bet for kiron virtual race
test('tc_KV003_VerifyThatUserIsAbleToPlaceAWinBetForKironVirtualRace', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on first Bet button
  await _RacingPage.rc_ClickBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "30", "Win", "30")
  //await page.pause()
})

//Verify that user is not able to place a place only bet for kiron virtual Races 
test('tc_KV004_VerifyThatUserIsNotAbleToPlaceAPlaceOnlyBetForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on first Bet button
  await _RacingPage.rc_ClickBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyValidationWhenPlaceOnlyBetIsPlaced() 
  //await page.pause()
})

//Verify that user is able to place a wind & place bet for kirion virtual races 
test('tc_KV005_VerifyThatUserIsAbleToPlaceAWinAndPlaceBetForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on first Bet button
  await _RacingPage.rc_ClickBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("WinAndPlace",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "60", "Win", "30")
  //Verify bet details for second selction
  await _HomePage.rc_VerifyBetDetailsWhenBettinsForMultipleSelection("Place", "30")
  //await page.pause()
})

//Verify that validation message when place stake is grater than win stake for kiron virtual races
test('tc_KV006_UnableToPlaceASingleBetWhenPlaceIsGreaterThanWinForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on first Bet button
  await _RacingPage.rc_ClickBetButton("1st")
  //Enter win amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Enter an ammount for place bet
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place",'40')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyValidationWhenPlaceIsGraterThanWin()
  //await page.pause()
})

//Verify that user is able to place bet using Each Way for kiron virtual Races 
test('tc_KV007_VerifyPlacingABetUsingEachWayForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on first Bet button
  await _RacingPage.rc_ClickBetButton("1st")
  //Enter an ammount for win bet
  await _HomePage.rc_EnterAStakeViaEachWay("30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "60", "Each Way", "60")
  //await page.pause()
})

//Verify that user is able to place a single bet for two selections using multiple options for kiron Races
test('tc_KV008_VerifyPlacingASingleBetForTwoSelectionsUsingMultipleOptionsForKironRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on first Bet button
  await _RacingPage.rc_ClickBetButton("1st")
  //Click on second Bet button
  await _RacingPage.rc_ClickBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Single", "Win", "30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  //  await _HomePage.rc_VerifyBettsSuccessMessage()  
  //Store slip id and click Ok from succuss messge
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "60", "Win", "30")
  // await page.pause()

})

//Verify that user is able to place a double bet for two races using multiple options for TAB races
test('tc_KV009_VerifyPlacingADoubleBetForTwoRacesUsingMultipleOptionsForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on first Bet button
  await _RacingPage.rc_ClickBetButton("1st")
  //Click on first upcomming race
  await _RacingPage.rc_ClickOnUpcomingRaces("1st") 
  //Click on first Bet button on upcomming race
  await _RacingPage.rc_ClickBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Double", "Win", "30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForWinDoubleBet(slipId, "30", "Double", "00")
  // await page.pause()

})

//Verify that user is able to place bet using quinella for kiron virtual races
test('tc_KV010_VerifyPlacingABetUsingQuinellaForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron") 
  //Click on quinella
  const _Next15Page = new Next15Page(page)
  await _Next15Page.rc_ClickAMarketFromRAceCard("Quinella")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1,"1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2,"2nd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Quinella","30")
})

//Verify that user is able to place bet using Exacta for kiron virtual races
test('tc_KV011_VerifyPlacingABetUsingExactaForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")
  //Click on quinella
  const _Next15Page = new Next15Page(page)
  //Click on Exacta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Exacta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1, "1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2, "2nd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "30", "Exacta", "30")
})

//Verify that user is able to place bet using Reverse Exacta for kiron virtual races
test('tc_KV012_VerifyPlacingABetUsingReverseExactaForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on quinella
  const _Next15Page = new Next15Page(page)
  //Click on Exacta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Exacta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelection(1, "Any")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelection(2, "Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "60", "Reverse Exacta", "30")
})

//Verify that trio tab is visible for kiron virtual races
test('tc_KV013_VerifyThatTrioTabIsVisibleForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Next15
  await _HomePage.rc_ClickAnItemFromTopMenu("Next")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  //Click on quinella
  const _Next15Page = new Next15Page(page)  
  //Verify trio tab
  await _Next15Page.rc_VerifyThatTrioButtionIsVisibleForKironVirtualRaces()  
})

//Verify that user is able to place bet using trio for kiron virtual races
test('tc_KV014_VerifyPlacingABetUsingTrioForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron") 
  const _Next15Page = new Next15Page(page)
  //Click on Trio
  await _Next15Page.rc_ClickAMarketFromRAceCard("Trio")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForTrio(1, "1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForTrio(2, "2nd")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTrio(3, "3rd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "30", "Trio", "30")
})

//Verify that user is able to place bet using Trifecta for kiron virtual races
test('tc_KV015_VerifyPlacingABetUsingTrifectaForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password, "No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")
  const _Next15Page = new Next15Page(page)  
  //Click on Trifecta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Trifecta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1, "1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2, "2nd")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3, "3rd")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win", '30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId, "30", "Trifecta", "30")
})

//Verify that user is able to place bet using combination Trifecta for kiron virtual races
test('tc_KV016_VerifyPlacingABetUsingCombinationTrifectaForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")   
  const _Next15Page = new Next15Page(page)
  //Click on Trifecta
  await _Next15Page.rc_ClickAMarketFromRAceCard("Trifecta")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1,"Any")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2,"Any")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3,"Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"180","Combination Trifecta","30")
})

//Verify that user is able to place bet using First4 for kiron virtual races
test('tc_KV017_VerifyPlacingABetUsingFirst4ForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")  
  const _Next15Page = new Next15Page(page)
  //Click on First 4
  await _Next15Page.rc_ClickAMarketFromRAceCard("First 4")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(1,"1st")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(2,"2nd")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(3,"3rd")
  //Select 3rd from selection 4
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(4,"4th")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss message  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","First 4","30")
})

//Verify that user is able to place bet using Combination First4 for kiron races
test('tc_KV018_VerifyPlacingABetUsingCombinationFirst4ForKironVirtualRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage = new RacingPage(page)
  //Click on kiron virtual race
  await _RacingPage.rc_ClikOnRacingType("Kiron")
  const _Next15Page = new Next15Page(page)
  //Click on Trifecta
  await _Next15Page.rc_ClickAMarketFromRAceCard("First 4")
  //Select 1st from selection 1
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(1,"Any")
  //Select 2nd from selection 2
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(2,"Any")
  //Select 3rd from selection 3
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(3,"Any")
  //Select 3rd from selection 4
  await _Next15Page.rc_SelectAnOptionFromSelectionForFirst4(4,"Any")
  //Click Add to bet slip
  await _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss message  
  const slipId = await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"720","Combination First 4","30")
})










































