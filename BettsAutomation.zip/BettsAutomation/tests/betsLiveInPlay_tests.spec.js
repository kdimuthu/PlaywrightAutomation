
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { login } from '../testdata/testdata.json';
import {LiveInPage} from '../pages_betts/liveinpage.js';


//Verify Minimum Slip Amount Validation for live Cricket Sports
test('tc_LI001_VerifyMiniumuSlipAmountValidationForLiveCricketSports', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
    //Click on first game in live page
    const _LiveInPage=new LiveInPage(page)
    await _LiveInPage.rc_ClickOnAGame("First")
    //Click on first odd button
    await _LiveInPage.rc_ClickOnOddButtonInrMarketFromSingleSportView("First")    
    //Enter bet amount
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'25')
    //Click Place Bet button
    await _HomePage.rc_ClickPlaceBet()
    //Verify validation
    await _HomePage.rc_VerifyMinimumSlipAmountValidation()     
})

//Verify that punter is able to place a bet for live cricket sport 
test('tc_LI002_VerifyThatUserIsAbleToPlaceABetForLiveCricketSport', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on first game in live page
  const _LiveInPage=new LiveInPage(page)
  await _LiveInPage.rc_ClickOnAGame("First")
  //Click on first odd button
  await _LiveInPage.rc_ClickOnOddButtonInrMarketFromSingleSportView("First")    
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet() 
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
//  await page.pause()  
})

//Verify that punter is able to place a bet for different market from single Sport View
test('tc_LI003_VerifyThatUserIsAbleToPlaceABetForDifferentMarketForLiveCricketSport', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No") 
  //Click on first game in live page
  const _LiveInPage=new LiveInPage(page)
  await _LiveInPage.rc_ClickOnAGame("First")
  //Click on a deferent market
  await _LiveInPage.rc_ClickOnSecondMarketFromSingleSportView()
  //Click on first odd button in second market
  await _LiveInPage.rc_ClickOnOddButtonInrMarketFromSingleSportView("Third") 
  //Enter bet amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"30","30")
  //await page.pause()  
})

//Verify that punter is able to place bets for live cricket sports Single bets using multiple options
test('tc_LI004_VerifyThatUserIsAbleToPlaceSingleBetsUsingMultipleOptionsForLiveCricketSports', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on first game in live page
  const _LiveInPage=new LiveInPage(page)
  await _LiveInPage.rc_ClickOnAGame("First") 
  //Click on first odd button
  await _LiveInPage.rc_ClickOnOddButtonInrMarketFromSingleSportView("First")   
  //Click on a deferent market
  await _LiveInPage.rc_ClickOnSecondMarketFromSingleSportView()  
  //Click on first odd button in second market
  await _LiveInPage.rc_ClickOnOddButtonInrMarketFromSingleSportView("Third")  
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Single","Win","30")  
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss message  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForOutrightSport(slipId,"60","30")
 // await page.pause()  
})

//Verify that punter is able to place bets for live cricket sports double bets using multiple options
test('tc_LI005_VerifyThatUserIsAbleToPlaceDoubleBetsUsingMultipleOptionsForLiveCricketSports', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username,login[0].password,"No")
  //Click on first game in live page
  const _LiveInPage=new LiveInPage(page)
  await _LiveInPage.rc_ClickOnAGame("First") 
  //Click on first odd button
  await _LiveInPage.rc_ClickOnOddButtonInrMarketFromSingleSportView("First")   
  //Click on a deferent market
  await _LiveInPage.rc_ClickOnSecondMarketFromSingleSportView()  
  //Click on first odd button in second market
  await _LiveInPage.rc_ClickOnOddButtonInrMarketFromSingleSportView("Third")  
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Double","Win","30")  
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Store slip id and click Ok from succuss message  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForWinDoubleBetsForCricketSports(slipId,"30","00")  
  //await page.pause()  
})

