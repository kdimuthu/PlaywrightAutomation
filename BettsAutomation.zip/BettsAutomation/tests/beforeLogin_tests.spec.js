
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { Next15Page } from '../pages_betts/next15page.js';
import { RacingPage } from '../pages_betts/racingpage.js';

//Verify that punter is not able place bet without login.
test('tc_BL001_VerifyThatUserIsUnableToPlaceBetsWithoutLogin',async ({page})=>{
    const _HomePage=new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click on Next15
    await _HomePage.rc_ClickAnItemFromTopMenu("Next")
    //Click on a Bet
    const _Next15Page = new Next15Page(page)
    await _Next15Page.rc_ClickBetOrSPButtonOfAGivenRaceNumber(1)
    //Verify validation message
    await _HomePage.rc_VerifyValidationMessageWhenBetingWitohutLoging()
}) 

//Verify the validation message when punter trying to access kiron virtual section without login.
test('tc_BL002_VerifyThatUserIsUnableToNavigatesToKironVirtualWithoutLogin',async ({page})=>{
    const _HomePage=new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click on Racing
    await _HomePage.rc_ClickAnItemFromTopMenu("Racing")    
    //Click on kiron virtual racing
    const _RacingPage = new RacingPage(page)
    await _RacingPage.rc_ClikOnRacingType("Kiron")    
    //Verify validation message
    await _HomePage.rc_VerifyValidationMessageWhenAccessingKirionVirtualSectionWithoutLoging()
}) 
