
import { test, expect } from '@playwright/test';
import { HomePage } from '../pages_betts/homepage.js';
import { LoginPage } from '../pages_betts/loginpage.js';
import { login } from '../testdata/testdata.json'
import {RacingPage} from '../pages_betts/racingpage.js'
import { Next15Page } from '../pages_betts/next15page.js';

//Verify Minimum Slip Amount Validation for SIS Races
test('tc_SIC001_VerifyMiniumuSlipAmountValidationForSISRaces', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
    //Click on Racing
    await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
    const _RacingPage=new RacingPage(page)
    //Click on first SIS race
    await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
    //Click on first SP/Odd/Bet   
    await _RacingPage.rc_ClickSPOddOrBetButton("1st")
    //Enter bet amount
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'25')
    //Click Place Bet button
    await _HomePage.rc_ClickPlaceBet()
    //Verify validation
    await _HomePage.rc_VerifyMinimumSlipAmountValidation()     
}) 

//Verify Minimum Stake Value Validation for SIS races
test('tc_SIC002_VerifyMiniumuStakeValueValidation', async ({ page }) => {
    const _HomePage = new HomePage(page)
    //Open the application
    await _HomePage.rc_OpenApplication()
    //Click login profile icon
    await _HomePage.rc_ClickLoginIcon()
    //Click login button
    await _HomePage.rc_ClickLogin()
    const _LoginPage = new LoginPage(page)
    //Call login funtion
    await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
    //Click on Racing
    await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
    const _RacingPage=new RacingPage(page)
    //Click on first SIS race
    await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
    //Click on a Bet    
    await _RacingPage.rc_ClickSPOddOrBetButton("1st")
    //Click on first SP/Odd/Bet 
    await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
    //Enter bet amount for first race slip
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'20')
    //Enter bet amount for first race slip
    await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place",'5')
    //Click Place Bet button
    await _HomePage.rc_ClickPlaceBet()
    //Verify validation
    await _HomePage.rc_VerifyMinimumStakeValueValidation()
     
})

//Verify that user is able to place a bet for SIS Races from Todays tab
test('tc_SIS003_VerifyThatUserIsAbleToPlaceABetForSISRacesFromTodaysTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()
})

//Verify that user is able to place a bet for SIS Races from Tomorrow tab
test('tc_SIS004_VerifyThatUserIsAbleToPlaceABetForSISRacesFromTomorrowTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on tomorrow link
  _RacingPage.rc_NavigatesToTodayOrTomorowTab("Tomorrow")
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRaceFromTomorrowTab("SIS")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()
})

//Verify that user is able to place a win bet for SIS Races 
test('tc_SIS005_VerifyThatUserIsAbleToPlaceAWinBetForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()
}) 
 
//Verify that user is not able to place a place only bet for SIS Races 
test('tc_SIS006_VerifyThatUserIsNotAbleToPlaceAPlaceOnlyBetForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet validation message
  await _HomePage.rc_VerifyValidationWhenPlaceOnlyBetIsPlaced() 
  //await page.pause()
})

//Verify that user is able to place a wind & place bet for SIS Races 
test('tc_SIS007_VerifyThatUserIsAbleToPlaceAWinAndPlaceBetForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("WinAndPlace",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Win","30")
  //Verify bet details for second selction
  await _HomePage.rc_VerifyBetDetailsWhenBettinsForMultipleSelection("Place","30")
  //await page.pause()
})

//Verify that validation message when place stake is grater than win stake for SIS
test('tc_SIS008_UnableToPlaceASingleBetWhenPlaceIsGreaterThanWinForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter win amount
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Enter an ammount for place bet
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Place",'40')   
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyValidationWhenPlaceIsGraterThanWin()
  //await page.pause()
})

//Verify that user is able to place bet using Each Way for SIS Races 
test('tc_SIS009_VerifyPlacingABetUsingEachWayForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
   //Enter an ammount for win bet
   await _HomePage.rc_EnterAStakeViaEachWay("30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Each Way","60")
  //await page.pause()
})

//Verify that user is able to place bet using forecast for SIS races
test('tc_SIS010_VerifyPlacingABetUsingForecastForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS") 
  const _Next15Page = new Next15Page(page)     
  //Click on forcast
  _Next15Page.rc_ClickAMarketFromRAceCard("Forecast")
  //Select 1st from selection 1
  _Next15Page.rc_SelectAnOptionFromSelection(1,"1st")
  //Select 2nd from selection 2
  _Next15Page.rc_SelectAnOptionFromSelection(2,"2nd")
  //Click Add to bet slip
  _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Forecast","30")
})

//Verify that user is able to place bet using reverse forecast for SIS races
test('tc_SIS011_VerifyPlacingABetUsingReverseForecastForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS") 
  const _Next15Page = new Next15Page(page)  
  //Click on forcast
  _Next15Page.rc_ClickAMarketFromRAceCard("Forecast")
  //Select Any from selection 1
  _Next15Page.rc_SelectAnOptionFromSelection(1,"Any")
  //Select Any from selection 2
  _Next15Page.rc_SelectAnOptionFromSelection(2,"Any")
  //Click Add to bet slip
  _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Reverse Forcast","30")
})

//Verify that user is able to place bet using combination forecast for SIS races
test('tc_SIS012_VerifyPlacingABetUsingCombinationForecastForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS") 
  const _Next15Page = new Next15Page(page)
  //Click on forcast
  _Next15Page.rc_ClickAMarketFromRAceCard("Forecast")
  //Select Any from selection 1
  _Next15Page.rc_SelectAnOptionFromSelection(1,"Any")
  //Select Any from selection 2
  _Next15Page.rc_SelectAnOptionFromSelection(2,"Any")
  //Select Any from selection 3
  _Next15Page.rc_SelectAnOptionFromSelection(3,"Any")
  //Click Add to bet slip
  _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"180","Combination Forcast","30")
})

//Verify that user is able to place bet using tricast for SIS races
test('tc_SIS013_VerifyPlacingABetUsingTricast', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  const _Next15Page = new Next15Page(page)
  //Click on Tricast
  _Next15Page.rc_ClickAMarketFromRAceCard("Tricast")
  //Select 1st from selection 1
  _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1,"1st")
  //Select 2nd from selection 2
  _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2,"2nd")
  //Select 3rd from selection 3
  _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3,"3rd")
  //Click Add to bet slip
  _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Tricast","30")
})

//Verify that user is able to place bet using reverse tricast for SIS races
test('tc_SIS014_VerifyPlacingABetUsingReverseTricastForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  const _Next15Page = new Next15Page(page)
  //Click on Tricast
  _Next15Page.rc_ClickAMarketFromRAceCard("Tricast")
  //Select 1st from selection 1
  _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1,"Any")
  //Select 2nd from selection 2
  _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2,"Any")
  //Select 3rd from selection 3
  _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3,"Any")
  //Click Add to bet slip
  _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"180","Reverse Tricast","30")
})

//Verify that user is able to place bet using combination tricast for SIS races
test('tc_SIS015_VerifyPlacingABetUsingCombinationTricastForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")
  const _Next15Page = new Next15Page(page)
  //Click on Tricast
  _Next15Page.rc_ClickAMarketFromRAceCard("Tricast")
  //Select Any from selection 1
  _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(1,"Any")
  //Select Any from selection 2
  _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(2,"Any")
  //Select Any from selection 3
  _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(3,"Any")
  //Select Any from selection 3
  _Next15Page.rc_SelectAnOptionFromSelectionForTricasst(4,"Any")
  //Click Add to bet slip
  _Next15Page.rc_ClickOnAddToBetSlipButton()
  //Enter bet amount 
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"720","Combination Tricast","30")
})

//Verify that user is able to place a single bet for two races using multiple options for SIS Races
test('tc_SIS016_VerifyPlacingASingleBetForTwoRacesUsingMultipleOptionsForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")   
  //Clik on Bet for first race    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Clik on Bet for second race    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Single","Win","30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()  
  //Store slip id and click Ok from succuss messge
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"60","Win","30")
  // await page.pause()

})

//Verify that user is able to place a double bet for two races using multiple options for SIS races
test('tc_SIS017_VerifyPlacingADoubleBetForTwoRacesUsingMultipleOptionsForSISRaces', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("SIS")   
  //Clik on Bet for first race    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Click on Racing again
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  //Click on tomorow link
  await _RacingPage.rc_NavigatesToTodayOrTomorowTab("Tomorrow")
  //Click on first SIS race on tomorrow tab
  await _RacingPage.rc_ClickOnAvailableFirstNextRaceFromTomorrowTab("SIS")
  //Clik on Bet for second race    
  await _RacingPage.rc_ClickSPOddOrBetButton("1st")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceBetAmoumtUsingSinbleOrDoubleInMultipleOptions("Double","Win","30")
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()  
   //Verify Bet succuss message
   await _HomePage.rc_VerifyBettsSuccessMessage()  
  //Store slip id and click Ok from succuss messge
   const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()
  //Click login profile icon to navigates to My bets secion
   await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
   await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
   await _HomePage.rc_VerifyBetDetailsInMyBetsSectionForWinDoubleBet(slipId,"30","Double","00")
  // await page.pause()

})

//Verify that user is able to place a bet from virtual tab
test('tc_SIS018_VerifyThatUserIsAbleToPlaceABetFromVirtualTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on tomorrow link
  await _RacingPage.rc_NavigatesToAllAusNZVirtual("Virtual")
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("Virt")   
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()
})

//Verify that user is able to place a bet from UK and Ireland tab
test('tc_SIS019_VerifyThatUserIsAbleToPlaceABetFromUKAndIrelandTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on tomorrow link
  await _RacingPage.rc_NavigatesToAllAusNZVirtual("UK")
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("Virt")   
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()
})

//Verify that user is able to place a bet from France tab
test('tc_SIS020_VerifyThatUserIsAbleToPlaceABetFromFranceTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on tomorrow link
  await _RacingPage.rc_NavigatesToAllAusNZVirtual("France")
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("Virt")   
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()
})

//Verify that user is able to place a bet from USA tab
test('tc_SIS021_VerifyThatUserIsAbleToPlaceABetFromUSATab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on tomorrow link
  await _RacingPage.rc_NavigatesToAllAusNZVirtual("USA")
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("Virt")   
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()
})

//Verify that user is able to place a bet from Other tab
test('tc_SIS022_VerifyThatUserIsAbleToPlaceABetFromOtherTab', async ({ page }) => {
  const _HomePage = new HomePage(page)
  //Open the application
  await _HomePage.rc_OpenApplication()
  //Click login profile icon
  await _HomePage.rc_ClickLoginIcon()
  //Click login button
  await _HomePage.rc_ClickLogin()
  const _LoginPage = new LoginPage(page)
  //Call login funtion
  await _LoginPage.rc_Login(login[0].username, login[0].password,"No")
  //Click on Racing
  await _HomePage.rc_ClickAnItemFromTopMenu("Racing")
  const _RacingPage=new RacingPage(page)
  //Click on tomorrow link
  await _RacingPage.rc_NavigatesToAllAusNZVirtual("Other")
  //Click on first SIS race
  await _RacingPage.rc_ClickOnAvailableFirstNextRace("Virt")   
  //Click on a Bet    
  await _RacingPage.rc_ClickSPOddOrBetButton("2nd")
  //Enter bet amount for first race slip
  await _HomePage.rc_EnterWinPlaceOrStakeBetAmoumt("Win",'30')
  //Click Place Bet button
  await _HomePage.rc_ClickPlaceBet()
  //Verify Bet succuss message
  await _HomePage.rc_VerifyBettsSuccessMessage()
  //Store slip id and click Ok from succuss messge  
  const slipId=await _HomePage.rc_StoreSlipIDAndClickOK()  
  //Click login profile icon to navigates to My bets secion
  await _HomePage.rc_ClickProfileIconAfterLogin()
  //Click on My Betss
  await _HomePage.rc_ClickAnItemFromRighMenu("Bets")
  //Verify bet details
  await _HomePage.rc_VerifyBetDetailsInMyBetsSection(slipId,"30","Win","30")
  //await page.pause()
})


  